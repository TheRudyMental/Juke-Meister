package Screen;

/**
 *
 * @author Grant Brown
 * This interface is to ensure that each screen class will implement a display method
 */
public interface ScreenInterface{
	public static ScreenInterface getInstance() {
		return null;
	}
}
