package Screen;

import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

public class Screen_1a extends GridPane implements ScreenInterface{

	private static Screen_1a instance;

	private Screen_1a() {
		setConstraints();
		makeComponents();
	}

	/**
	 * The getInstance method returns the singleton instance of the screen
	 *  @return instance
	 */
	public static ScreenInterface getInstance(){
		if(instance != null){
			return instance;
		}
		else{
			instance = new Screen_1a();
			return instance;
		}
	}

	/**
	 * This method is a helper to the constructor of the class to make itself
	 * without having an extremely long constructor
	 *
	 */
	private void setConstraints(){
		int columnNumber = 3;
		int rowNumber = 6;
		for(int i = 0; i < columnNumber;i++){
			ColumnConstraints col0 = new ColumnConstraints();
			col0.setPercentWidth(40);
			if(i == 1){
				col0.setPercentWidth(20);
			}//end if
			this.getColumnConstraints().add(col0);
		}//end for

		for(int i = 0; i<rowNumber;i++){
			RowConstraints row0 = new RowConstraints();
			row0.setPercentHeight(10);
			if(i == 1){//if its the message row
				row0.setPercentHeight(5);
			}
			else if(i == 3){//the list's row
				row0.setPercentHeight(50);
			}
			else if(i == 4){//the browse button
				row0.setPercentHeight(15);
			}
			this.getRowConstraints().add(row0);
		}//end for
	}//end setConstraints


	/**
	 * This method defines the components on the screen and adds them to it.
	 */
	private void makeComponents(){
		Label vName = new Label("Venue Name");
		Label message = new Label("Message");

		this.add(vName,1,0,1,1);
		this.add(message,1,1,1,1);

		GridPane.setHalignment(vName, HPos.CENTER);
		GridPane.setHalignment(message,HPos.CENTER);

		Label pop = new Label("Popular Songs");
		Label newSongs = new Label("New Songs");

		this.add(pop,0,2,1,1);
		this.add(newSongs,2,2,1,1);

		GridPane.setHalignment(pop,HPos.CENTER);
		GridPane.setHalignment(newSongs,HPos.CENTER);
		//The list stuff will go here, empty for now

		Button browse = new Button("Browse");
		//Add listener for the button later
		this.add(browse,1,4,1,1);
		GridPane.setHalignment(browse,HPos.CENTER);

		Label nowPlaying = new Label("Now Playing"); //make this its own component later
		this.add(nowPlaying,1,5,1,1);
		GridPane.setHalignment(nowPlaying,HPos.CENTER);
	}//end makeComponents

}
